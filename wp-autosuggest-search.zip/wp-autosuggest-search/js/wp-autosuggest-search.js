$("#search-input").autocomplete({
    source: function(request, response) {
        $.ajax({
            url: wpass_options.ajaxurl,
            dataType: "json",
            data: {
                action: 'wp-autosuggest-search',
                q: request.term,
                _wpnonce: wpass_options.nonce
            },
            success: function(data) {
                response(data);
            }
        });
    },
    minLength: wpass_options.min_chars,
    select: function(event, ui) {
        window.location.href = wpass_options.ajaxurl + '?action=wpass-post-url&title=' + encodeURIComponent(ui.item.value);
    },
    open: function() {
        var autocomplete = $(this).autocomplete("widget");
        autocomplete.addClass("custom-autocomplete");
        autocomplete.find(".ui-menu-item").each(function() {
            $(this).html('<span class="item-text">' + $(this).text() + '</span><span class="item-remove">Remove</span><p class="item-category">Trending</p>');
        });
    }
});
