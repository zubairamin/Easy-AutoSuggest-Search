<?php
/**
 * Plugin Name: WP AutoSuggest Search
 * Plugin URI: https://www.ideafist.com/wp-autosuggest-search/
 * Description: Adds an auto-suggest feature to the default WordPress search bar using jQuery UI Autocomplete.
 * Version: 1.0
 * Author: Ideafist (Pvt.) Ltd.
 * Author URI: https://www.ideafist.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wp-autosuggest-search
 */

/**
 * Registers the script and stylesheet.
 */
function wpass_init() {
    $plugin_data = get_file_data(__FILE__, array('Version' => 'Version'), 'plugin');

    // Register JavaScript
    wp_register_script(
        'wp-autosuggest-search-js',
        plugins_url("js/wp-autosuggest-search.js", __FILE__),
        array('jquery', 'jquery-ui-autocomplete'),
        $plugin_data['Version'],
        true
    );

    // Localize JavaScript
    wp_localize_script(
        'wp-autosuggest-search-js',
        'wpass_options',
        array(
            'url'           => admin_url('admin-ajax.php'),
            'nonce'         => wp_create_nonce('wp-autosuggest-search'),
            'ajaxurl'       => add_query_arg(
                array(
                    'action'   => 'wp-autosuggest-search',
                    '_wpnonce' => wp_create_nonce('wp-autosuggest-search'),
                ),
                admin_url('admin-ajax.php')
            ),
            'min_chars'     => get_option('wpass_min_chars', 2),
            'results_limit' => get_option('wpass_results_limit', 10),
        )
    );

    // Register CSS
    wp_register_style(
        'wp-autosuggest-search-css',
        plugins_url("css/wp-autosuggest-search.css", __FILE__),
        array(),
        '1.0' // Update this version number
    );
}
add_action('init', 'wpass_init', 9);

/**
 * Enqueues the script and style.
 */
function wpass_enqueue_scripts() {
    wp_enqueue_script('wp-autosuggest-search-js'); // Enqueue JavaScript
    wp_enqueue_style('wp-autosuggest-search-css'); // Enqueue CSS
}
add_action('wp_enqueue_scripts', 'wpass_enqueue_scripts');


 
/**
 * Handles the AJAX request for the search term.
 */
function wpass_ajax_response() {
    check_ajax_referer('wp-autosuggest-search');

    $s = trim(stripslashes($_GET['q']));
    $min_chars = get_option('wpass_min_chars', 2);
    $results_limit = get_option('wpass_results_limit', 10);

    if (strlen($s) < $min_chars) {
        echo wp_json_encode(array());
        wp_die();
    }

    $query_args = array(
        's'           => $s,
        'post_status' => 'publish',
        'posts_per_page' => $results_limit,
    );

    $query = new WP_Query($query_args);

    if ($query->posts) {
        $results = wp_list_pluck($query->posts, 'post_title');
        echo wp_json_encode($results);
    } else {
        echo wp_json_encode(array());
    }

    wp_die();
}
add_action('wp_ajax_wp-autosuggest-search', 'wpass_ajax_response');
add_action('wp_ajax_nopriv_wp-autosuggest-search', 'wpass_ajax_response');

/**
 * Handles the AJAX request for a specific title.
 */
function wpass_post_url() {
    check_ajax_referer('wpass-post-url');

    $post = wpass_get_post_id_from_title(trim(stripslashes($_REQUEST['title'])));

    if ($post) {
        echo esc_url(get_permalink($post));
    }

    wp_die();
}
add_action('wp_ajax_wpass-post-url', 'wpass_post_url');
add_action('wp_ajax_nopriv_wpass-post-url', 'wpass_post_url');

/**
 * Examines a title and tries to determine the post ID it represents.
 *
 * @param string $title Post title to check.
 * @return int Post ID or 0 on failure.
 */
function wpass_get_post_id_from_title($title) {
    global $wpdb;

    $post_id = wp_cache_get('wpass_post_title' . $title, 'post');

    if (false === $post_id) {
        $post_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT ID FROM $wpdb->posts WHERE post_title = %s AND post_status = 'publish' LIMIT 1",
                $title
            )
        );

        wp_cache_set('wpass_post_title' . $title, $post_id, 'post');
    }

    return absint($post_id);
}

/**
 * Adds settings link to the plugin page.
 *
 * @param array $links Existing links.
 * @return array Modified links.
 */
function wpass_plugin_settings_link($links) {
    $settings_link = '<a href="options-general.php?page=wp-autosuggest-search">Settings</a>';
    array_push($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'wpass_plugin_settings_link');

/**
 * Registers settings for the plugin.
 */
function wpass_register_settings() {
    register_setting('wpass_settings_group', 'wpass_min_chars');
    register_setting('wpass_settings_group', 'wpass_results_limit');
}
add_action('admin_init', 'wpass_register_settings');

/**
 * Creates the settings page for the plugin.
 */
function wpass_settings_page() {
    ?>
    <div class="wrap">
        <h1>WP AutoSuggest Search Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('wpass_settings_group');
            do_settings_sections('wpass_settings_group');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Minimum Characters</th>
                    <td>
                        <input type="number" name="wpass_min_chars" value="<?php echo esc_attr(get_option('wpass_min_chars', 2)); ?>" />
                        <p class="description">The minimum number of characters required before suggestions are shown.</p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Results Limit</th>
                    <td>
                        <input type="number" name="wpass_results_limit" value="<?php echo esc_attr(get_option('wpass_results_limit', 10)); ?>" />
                        <p class="description">The maximum number of suggestions to display.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

/**
 * Adds settings menu item to the admin menu.
 */
function wpass_add_settings_menu() {
    add_options_page('WP AutoSuggest Search Settings', 'WP AutoSuggest Search', 'manage_options', 'wp-autosuggest-search', 'wpass_settings_page');
}
add_action('admin_menu', 'wpass_add_settings_menu');
