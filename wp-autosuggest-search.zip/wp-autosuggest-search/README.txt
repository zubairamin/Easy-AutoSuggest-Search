=== WP AutoSuggest Search ===
Contributors: Ideafist (Pvt.) Ltd.
Donate link: https://www.ideafist.com
Tags: search, autocomplete, autosuggest, ajax search, search bar, jquery, ui
Requires at least: 5.0
Tested up to: 6.3
Stable tag: 1.1
Requires PHP: 7.0
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A lightweight plugin that adds an auto-suggest feature to the default WordPress search bar using jQuery UI Autocomplete.

== Description ==

WP AutoSuggest Search enhances the default WordPress search bar by adding an auto-suggest feature. It uses jQuery UI's Autocomplete function to display live search suggestions as the user types.

**Features:**
- Auto-suggests results from your WordPress posts based on the query.
- Dynamically update settings via the admin panel.
- Fully customizable to define minimum characters and maximum results.
- Seamless integration with any theme using the default WordPress search bar.
- Lightweight and easy to use.
  
This plugin makes it easier for users to find content quickly and improves the overall user experience on your WordPress site.

**Key Options:**
- **Minimum Characters**: Set the minimum number of characters required before suggestions appear.
- **Maximum Results**: Define the number of suggestions to display.

== Installation ==

1. Upload the `wp-autosuggest-search` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Configure the settings under `Settings > AutoSuggest Search`.

== Frequently Asked Questions ==

= Can I change the minimum number of characters required before suggestions appear? =
Yes, in the admin panel under `Settings > AutoSuggest Search`, you can set the minimum number of characters before the suggestions are triggered.

= Can I change the maximum number of suggestions displayed? =
Yes, you can adjust the maximum number of suggestions from the plugin settings in the admin panel.

= Will this plugin work with custom post types? =
Currently, the plugin is designed to work with WordPress posts. If you require custom post types, feel free to extend the functionality by modifying the query in the `wp_autosuggest_search_autocomplete` function.

== Screenshots ==

1. **Admin Settings Page** – Easily configure the minimum number of characters and maximum results.
2. **Autocomplete in Action** – A live preview of how the search bar autocompletes based on user input.

== Changelog ==

= 1.1 =
* Added admin settings page for dynamic customization of minLength and maxResults.
* Improved documentation and inline code comments.
* Tested up to WordPress 6.3.

= 1.0 =
* Initial release of the plugin with basic auto-suggest functionality.

== Upgrade Notice ==

= 1.1 =
New features added: Admin page for dynamic settings configuration.

== License ==

This plugin is licensed under the GPL v2 or later. For more information, see [https://www.gnu.org/licenses/gpl-2.0.html](https://www.gnu.org/licenses/gpl-2.0.html).
